#used Gaussian elimination program from ine.scripts.mit.edu

def myGauss(m):
    #eliminate columns
    for col in range(len(m[0])):
        for row in range(col+1, len(m)):
            r = [(rowValue * (-(m[row][col] / m[col][col]))) for rowValue in m[col]]
            m[row] = [sum(pair) for pair in zip(m[row], r)]
    #now backsolve by substitution
    ans = []
    m.reverse() #makes it easier to backsolve
    for sol in range(len(m)):
            if sol == 0:
                ans.append(m[sol][-1] / m[sol][-2])
            else:
                inner = 0
                #substitute in all known coefficients
                for x in range(sol):
                    inner += (ans[x]*m[sol][-2-x])
                #the equation is now reduced to ax + b = c form
                #solve with (c - b) / a
                ans.append((m[sol][-1]-inner)/m[sol][-sol-2])
    ans.reverse()
    return ans

#refer to pdf for where the numbers were derived.
print myGauss([[4.0,-1.0,-1.0,-1.0, 5.0],
               [-1.0,3.0,0.0,-1.0, 0.0],
               [-1.0,0.0,3.0,-1.0,5.0],
               [-1.0,-1.0,-1.0,4.0,0.0]])